<?php
// Ensure WordPress environment is loaded
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Check if the user is logged in
if (!is_user_logged_in()) {
    // Redirect to the login page
    wp_redirect(wp_login_url(get_permalink())); 
    exit; // Stop further execution
}

/* Template Name: CSR List */
get_header(); 

?>

<div class="container" style="max-width: 1000px; margin: 0 auto; padding: 10px; font-family: Arial, sans-serif; color: #333;">
<?php if (isset($_GET['submission_status']) && $_GET['submission_status'] === 'success') {
        echo '<div style="color: green; font-weight: bold; margin-bottom: 20px;">Details added successfully!</div>';
    }?>
    <h1 style=" color: #444; margin-bottom: 10px;">CSR Submissions</h1>

    <?php
    global $wpdb;
    $table_name = $wpdb->prefix . 'csr_submissions';
    $constituencies_table = $wpdb->prefix . 'constituencies';

    // Query to fetch CSR submissions along with constituency names
    $query = $wpdb->prepare("
        SELECT 
            submissions.csr_id,
            submissions.id,
            submissions.company,
            submissions.funding_from,
            submissions.funding_till,
            constituencies.name AS constituency_name,
            submissions.mandal,
            submissions.village,
            submissions.name_of_work,
            submissions.csr_fund,
            submissions.expenditure,
            submissions.status,
            submissions.work_category,
            submissions.date_sanctioned,
            submissions.executive_agency

        FROM 
            $table_name AS submissions
        INNER JOIN 
            $constituencies_table AS constituencies
        ON 
            submissions.constituency_id = constituencies.id
        ORDER BY 
            submissions.csr_id DESC
    ");

    $results = $wpdb->get_results($query);
    ?>

    <?php if ($results): ?>
        <table style="width: 90%; border-collapse: collapse; margin-bottom: 30px;">
            <thead>
                <tr style="background-color: #f7f7f7;  ">
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">CSR ID</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">ID</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">Company</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">Funding From</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">Funding Till</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">Constituency</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">Mandal</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">Village</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">Name of Work</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">CSR Fund</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">Expenditure</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">Status</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">Work Category</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">Date Sanctioned</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">Executive Agency</th>
                    <th style="padding: 10px; border-bottom: 2px solid #ddd;">Edit</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $row): ?>
                    <tr style="background-color: #fff; border-bottom: 1px solid #ddd;">
                        <td style="padding: 10px;"><?php echo esc_html($row->csr_id); ?></td>
                        <td style="padding: 10px;"><?php echo esc_html($row->id); ?></td>
                        <td style="padding: 10px;"><?php echo esc_html($row->company); ?></td>
                        <td style="padding: 10px;"><?php echo esc_html($row->funding_from); ?></td>
                        <td style="padding: 10px;"><?php echo esc_html($row->funding_till); ?></td>
                        <td style="padding: 10px;"><?php echo esc_html($row->constituency_name); ?></td>
                        <td style="padding: 10px;"><?php echo esc_html($row->mandal); ?></td>
                        <td style="padding: 10px;"><?php echo esc_html($row->village); ?></td>
                        <td style="padding: 10px;"><?php echo esc_html($row->name_of_work); ?></td>
                        <td style="padding: 10px;"><?php echo esc_html(number_format($row->csr_fund),0); ?></td>
                        <td style="padding: 10px;"><?php echo esc_html(number_format($row->expenditure,0)); ?></td>
                        <td style="padding: 10px;"><?php echo esc_html($row->status); ?></td>
                        <td style="padding: 10px;"><?php echo esc_html($row->work_category); ?></td>
                        <td style="padding: 10px;"><?php echo esc_html($row->date_sanctioned); ?></td>
                        <td style="padding: 10px;"><?php echo esc_html($row->executive_agency); ?></td>
                        <td style="padding: 10px;"><a href="<?php echo esc_url(add_query_arg('action', 'edit', add_query_arg('csr_id', $row->csr_id, home_url('/edit-csr')))); ?>" style="color: #0073aa; text-decoration: none;">Edit</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="  color: #666;">No records found.</p>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
